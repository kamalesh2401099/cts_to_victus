document.addEventListener('DOMContentLoaded', () => {
    // Disable manual scroll on New Arrivals container
    const newArrivalsContainer = document.querySelector('#home > .scrolling-wrapper-auto');
    if (newArrivalsContainer) {
      newArrivalsContainer.addEventListener('wheel', (e) => {
        e.preventDefault();
      });
    }
    document.getElementById("searchBar").addEventListener("input", function () {
        const query = this.value.toLowerCase();
        document.querySelectorAll(".book-card").forEach((card) => {
          const title = card.querySelector("h6").textContent.toLowerCase();
          card.style.display = title.includes(query) ? "block" : "none";
        });
      });
      
  
    // Search bar filtering for New Arrivals books
    const searchInput = document.getElementById('searchBar');
    const bookCards = document.querySelectorAll('#home .book-card');
  
    if (searchInput) {
      searchInput.addEventListener('input', () => {
        const filter = searchInput.value.toLowerCase();
  
        bookCards.forEach(card => {
          const title = card.querySelector('h6').textContent.toLowerCase();
          const author = card.querySelector('p').textContent.toLowerCase();
  
          if (title.includes(filter) || author.includes(filter)) {
            card.style.display = ''; // show
          } else {
            card.style.display = 'none'; // hide
          }
        });
      });
    }
  });
